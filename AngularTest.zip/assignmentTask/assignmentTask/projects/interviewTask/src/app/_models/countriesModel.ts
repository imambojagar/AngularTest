export interface Countries {
    countryName: string;
    team: Team[]
}

export interface Team {
    name: string;
    captain: boolean;
}

