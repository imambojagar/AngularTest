import { Component, OnInit } from '@angular/core';
import { Team, Countries } from '../../../_models/countriesModel';
import { ActivatedRoute } from '@angular/router';
import { HttpClientService } from '../../../services/http/http-client.service';

@Component({
  selector: 'sundayMobility-country-details',
  templateUrl: './country-details.component.html',
  styleUrls: ['./country-details.component.scss']
})
export class CountryDetailsComponent implements OnInit {

  teamDetails: Team[] = [];

  countries: Countries[] = [];


  constructor(private route: ActivatedRoute, private httpService: HttpClientService) { }

  ngOnInit(): void {
    this.route.queryParams.subscribe(data => {
      this.getContries(data.countryName);
    });
  }


  getContries(countryName) {
    this.httpService.getCountriesList().subscribe(data => {
      for (var key in data) {
        let temp: Countries = { countryName: '', team: [] };
        if (data.hasOwnProperty(key)) {
          if (key == countryName) {
            this.teamDetails = data[key];
          }
          temp.countryName = key;
          temp.team = data[key];
          this.countries.push(temp);
        }
      }
    });
  }

  sortAsc() {
    let regExp: RegExp = /\s+/;
    console.log("Mujeeb Ur Rahman".split(regExp)["Mujeeb Ur Rahman".split(regExp).length - 1]);

    this.teamDetails = this.teamDetails.sort(
      //(a, b) => 0 - (a.name.split(regExp)[a.name.split(regExp).length - 1] < b.name.split(regExp)[b.name.split(regExp).length - 1] ? 1 : -1)
      (a, b) => 0 - (a.name < b.name ? 1 : -1)
    )
  }


  sortAsc2(){
    let regExp: RegExp = /\s+/;
    console.log("Mujeeb Ur Rahman".split(regExp)["Mujeeb Ur Rahman".split(regExp).length - 1]);

    this.teamDetails = this.teamDetails.sort(
      (a, b) => 0 - (a.name.split(regExp)[a.name.split(regExp).length - 1] < b.name.split(regExp)[b.name.split(regExp).length - 1] ? 1 : -1)
      //(a, b) => 0 - (a.name < b.name ? 1 : -1)
    )
  }

}
