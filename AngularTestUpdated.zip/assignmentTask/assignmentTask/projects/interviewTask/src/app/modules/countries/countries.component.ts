import { Component, OnInit } from '@angular/core';
import { HttpClientService } from '../../services/http/http-client.service';
import { Countries } from '../../_models/countriesModel';



@Component({
  selector: 'sundayMobility-countries',
  templateUrl: './countries.component.html',
  styleUrls: ['./countries.component.scss']
})
export class CountriesComponent implements OnInit {

  countries: Countries[] = [];

  constructor(private httpService: HttpClientService) { }

  ngOnInit(): void {
    this.getContries();
  }

  getContries() {
    this.httpService.getCountriesList().subscribe(data => {
      for (var key in data) {
        let temp: Countries = { countryName: '', team: [] };
        if (data.hasOwnProperty(key)) {
          temp.countryName = key;
          temp.team = data[key];
          this.countries.push(temp);
        }
      }
      this.countries.sort((a,b) => 0 - (a > b ? 1 : -1));
    });
  }

}
